# Fast Blacklord multipair build — Sanezo X Ultra

- Uses the latest npm `blacklord-baileys` release: **1.0.1**.
- Requires Node.js 20 or newer.
- Uses Jimp 1.6.1 with updated image APIs.
- All direct old `baileys` imports were replaced.
- Per-session message retry store and `getMessage` are enabled.
- Startup version lookup is shared across sessions.
- Pairing/reconnect delays were reduced without allowing duplicate sockets.
- The `store is not defined` defensive fallback is included.
- Default bot name: `_*~𝐒𝐀𝐍𝐄𝐙𝐎 𝐗 𝐔𝐋𝐓𝐑𝐀~*_`.
- Console / panel log prints the plain name `SANEZO X ULTRA` (override with `CONSOLE_NAME`).
- Handler file renamed: `ElitePro.js` -> `Sanezo.js` (required from `index.js`).

Install with `npm install`, configure `.env`, then run `npm start`.
Do not copy old sessions or databases into the new build until the process starts cleanly.
