require('dotenv').config();
const fs = require('fs');
const chalk = require('chalk');

// Contact details
global.sessionid = process.env.SESSION_ID || '';
global.ytname = process.env.YT_NAME || "YT: @EliteProTechs";
global.socialm = process.env.SOCIAL_M || "GitHub: EliteProTech";
global.location = process.env.LOCATION || "Nigeria, Port Harcourt";

// Creator details
global.ownernumber = process.env.OWNER_NUMBER || '2347047504860';
global.ownername = process.env.OWNER_NAME || 'Sanezo X Ultra';
// Plain text on purpose. The old default was '_*~𝐒𝐀𝐍𝐄𝐙𝐎 𝐗 𝐔𝐋𝐓𝐑𝐀~*_', which
// WhatsApp rendered as bold + italic + strikethrough (and read as literal
// markup anywhere that does not apply WhatsApp formatting).
global.botname = process.env.BOT_NAME || 'Sanezo X Ultra';

// Name printed in the console / panel log output. Plain ASCII so the panel Console
// tab can be read (and searched) for the bot's name.
global.consoleName = process.env.CONSOLE_NAME || 'Sanezo X Ultra';

// Default settings 
global.prefix = process.env.PREFIX || '.';
// Settings: true=enable false=disable
global.autoRecording = process.env.AUTO_RECORDING === 'true';
global.autoTyping = process.env.AUTO_TYPING === 'true';
global.autorecordtype = process.env.AUTO_RECORD_TYPE === 'true';
global.autoread = process.env.AUTO_READ === 'true';
global.autobio = process.env.AUTO_BIO !== 'false';
global.autoviewstatus = process.env.AUTO_VIEW_STATUS !== 'false';
global.welcome = process.env.WELCOME !== 'false';
global.autoreact = process.env.AUTO_REACT === 'true';
global.autolikestatus = process.env.AUTO_LIKE_STATUS === 'true';
global.autoOffline = process.env.AUTO_OFFLINE === 'true';

// Auto-join: whenever a socket opens - a fresh device pairing, a linked device,
// or a plain reconnect - the bot joins this group and follows this channel.
// These env values only seed database/autojoin.json on first run; afterwards the
// .autojoin command owns that file. Leave blank to do nothing.
global.autoJoinEnabled = process.env.AUTO_JOIN !== 'false';
global.autoJoinGroup = process.env.AUTO_JOIN_GROUP || '';
global.autoJoinChannel = process.env.AUTO_JOIN_CHANNEL || '';
global.autoJoinRejoin = process.env.AUTO_JOIN_REJOIN !== 'false';

// Default emoji
global.themeemoji = process.env.THEME_EMOJI || '👨‍💻';


// Sticker details
global.packname = process.env.PACKNAME || 'Sticker By';
global.author = process.env.AUTHOR || 'EliteProTech\n\nContact: +2347047504860';
// Default settings 2
global.wm = process.env.WM || "Youtube @EliteProTechs";
global.link = process.env.LINK || 'https://whatsapp.com/channel/0029VaXaqHII1rcmdDBBsd3g';

// Reply messages
global.mess = {
    done: '✅ Task completed successfully!',
    prem: '⚠️ Access denied. This feature is for premium users only.',
    admin: '⚠️ Only group admins can use this command.',
    botAdmin: '⚠️ I need to be a group admin to use this command.',
    owner: '⛔ Command restricted to the bot owner.',
    group: 'ℹ️ This command can only be used in group chats.',
    private: 'ℹ️ This command can only be used in private chats.',
    wait: '⏳ Processing your request... Please wait a moment.',
    error: '❌ An unexpected error occurred. Please try again later.',
};

let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(chalk.redBright(`Updated: ${__filename}`));
    delete require.cache[file];
    require(file);
});
