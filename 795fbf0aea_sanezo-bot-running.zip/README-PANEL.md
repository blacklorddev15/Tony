# Sanezo X Ultra — exact copy of the running build

Pulled from `pedrodom.thecortana.tech` → server **Blacklord ✅** (`be2e9aa3`),
2026-10-19. This is not a rebuild from source — every file is the byte-for-byte
copy currently on that panel, including the `.env` it boots with.

Verified after download: all 44 files matched their on-server sizes, the JPEG
icon is intact (`ff d8 ff`), and all 16 JS files pass `node --check`.

## What this build is (and is not)

| | |
|---|---|
| Naming | `EliteProTech*` internal variables (pre-rebrand internals) |
| Per-user settings | **not present** — `helper/usersettings.js` does not exist in this build |
| Menu | single `.menu`, no `.menu2` / `.oldmenu` |
| Website pairing | Neon channel (`helper-varnox-neon.js`) — active |
| Telegram pairing | active (`TELEGRAM_TOKEN` in `.env`) |
| Token bridge | disabled (token revoked with 401) |

If you want the newer local build — per-user settings, `Sanezo` naming, `.menu2` —
that is a different package, not this one.

## Deploy on any panel

| Item | Value |
|---|---|
| Node | 20 or 22 (18 fails) |
| RAM | 256 MB min, 512 MB comfortable (~100–135 MB idle) |
| Disk | 500 MB+ for `node_modules` + ffmpeg |
| Start | `npm start` (egg `CMD_RUN`) |

1. Upload the zip to `/home/container`, **Unarchive**.
2. If it nests under a folder, move the contents up to `/home/container`.
3. `npm install --legacy-peer-deps` (the egg usually does this on first boot).
4. Start.

Expected boot:

```
[BOOT] Sanezo X Ultra – multi-session pairing build
[NET] web.whatsapp.com:443 reachable
[WEBSITE-PAIR] Website pairing loop started (1s interval)
[WEBSITE-PAIR] Neon channel online. Waiting for pairing requests...
```

`injected env (2) from .env` = both keys loaded. `(0)` means the panel mangled
`.env` (usually stored it as JSON) — rewrite as plain text.

## Do not run this twice against the same credentials

Two processes on one Telegram token get `409 Conflict`; two bots on one Neon
table race for pairing requests. Give a second instance its own token and database.

## Not included

`sessions/` — linked-device credentials, machine-bound, created on first pairing.
`database/users/` — per-user overrides, created on first write.
`node_modules/` — install on the panel.
