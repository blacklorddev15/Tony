// ============================================================
//   helper-bridge-token.js - token bridge channel
//
//   Same job as helper-varnox-neon.js, different transport: instead
//   of holding the Postgres credentials and reading the queue table
//   directly, this bot talks to the Token Bridge site over HTTPS and
//   authenticates with its own scoped token (BRIDGE_TOKEN).
//
//   The container therefore needs no database access at all, and the
//   link can be revoked from the site's admin page without touching
//   anything here.
//
//   Env:
//     BRIDGE_URL    e.g. https://token-bridge-eosin.vercel.app
//     BRIDGE_TOKEN  tb_...            (from the admin page, shown once)
// ============================================================
'use strict';

// Force IPv4-first DNS (containers/VPS often have no IPv6 route).
try { require('dns').setDefaultResultOrder('ipv4first'); } catch (_) { /* older node */ }

// Same socket registry the other channels use, so both can see the same sessions.
const { getWASocket } = require('./helper-varnox-neon');

const BRIDGE_URL = String(process.env.BRIDGE_URL || '').replace(/\/+$/, '');
const BRIDGE_TOKEN = String(process.env.BRIDGE_TOKEN || '');
const CONFIG_POLL_MS = 60000;
const REQUEST_TIMEOUT_MS = 15000;

// ── HTTP helpers ─────────────────────────────────────────────
async function api(path, body, method) {
  const init = {
    method: method || (body === undefined ? 'GET' : 'POST'),
    headers: {
      Authorization: `Bearer ${BRIDGE_TOKEN}`,
      'Content-Type': 'application/json',
    },
  };
  if (body !== undefined) init.body = JSON.stringify(body);

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  init.signal = controller.signal;

  let res;
  try {
    res = await fetch(`${BRIDGE_URL}${path}`, init);
  } finally {
    clearTimeout(timer);
  }

  if (res.status === 204) return null; // nothing pending

  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch (_) { /* non-JSON body */ }

  if (!res.ok) {
    const err = new Error(`${res.status} ${(data && data.error) || text || res.statusText}`);
    err.status = res.status;
    throw err;
  }
  return data;
}

// ── Queue operations ─────────────────────────────────────────
async function claimPairingRequest() {
  return api('/api/v1/pairings/claim', {});           // { id, phone } | null
}

async function setPairingCode(id, code) {
  await api(`/api/v1/pairings/${id}`, { code: String(code) });
}

async function markPairingConnected(id) {
  await api(`/api/v1/pairings/${id}`, { status: 'connected' });
}

async function markPairingFailed(id, msg) {
  await api(`/api/v1/pairings/${id}`, { status: 'failed', error: String(msg || 'Pairing failed.') });
}

async function recordSession(sessionId, phone, status) {
  try {
    await api(`/api/v1/sessions/${encodeURIComponent(sessionId)}`, {
      phone: String(phone || ''),
      status: String(status || 'disconnected'),
    }, 'PUT');
  } catch (e) {
    console.error('[TOKEN-BRIDGE] recordSession error:', e && e.message);
  }
}

// ── Remote config ────────────────────────────────────────────
// The admin page can push config changes; this is how the bot hears about them.
// onConfig is only called when something actually changed.
let _lastConfigJson = null;
let _announced = false;

async function refreshConfig(onConfig) {
  try {
    const d = await api('/api/v1/bot');
    const cfg = (d && d.config) || {};
    if (!_announced) {
      console.log('[TOKEN-BRIDGE] Token channel online. Waiting for pairing requests...');
      _announced = true;
    }
    const j = JSON.stringify(cfg);
    if (j !== _lastConfigJson) {
      _lastConfigJson = j;
      if (typeof onConfig === 'function') {
        try { await onConfig(cfg); } catch (e) { console.error('[TOKEN-BRIDGE] onConfig error:', e && e.message); }
      }
    }
  } catch (e) {
    console.error('[TOKEN-BRIDGE] bridge NOT reachable - ' + (e && (e.message || e)));
  }
}

// ── Main polling loop ────────────────────────────────────────
// starter: (sessionId, phone, pairingCodeCallback) => Promise<sock|void>
function startTokenBridgeLoop(starter, opts = {}) {
  if (!BRIDGE_URL || !BRIDGE_TOKEN) {
    console.warn('[TOKEN-BRIDGE] BRIDGE_URL/BRIDGE_TOKEN not set - token bridge disabled.');
    return;
  }

  const onConfig = opts.onConfig;

  console.log('[TOKEN-BRIDGE] Token bridge loop started (1s interval)');
  refreshConfig(onConfig);
  setInterval(() => refreshConfig(onConfig), CONFIG_POLL_MS);

  setInterval(async () => {
    try {
      const row = await claimPairingRequest();
      if (!row) return;

      const sessionId = `web_${row.phone}`;
      console.log(`[TOKEN-BRIDGE] Request #${row.id} for +${row.phone} claimed from the site.`);
      _announced = true;

      // Only fail a request that never produced a code - once the code is out the user
      // needs time to type it, and the site refuses to downgrade an already-connected row.
      let codeSent = false;
      const watchdog = setTimeout(() => {
        if (!codeSent) {
          markPairingFailed(row.id, 'Timed out waiting for WhatsApp pairing code.').catch(() => {});
        }
      }, 90000);

      await starter(sessionId, row.phone, async (code) => {
        clearTimeout(watchdog);
        codeSent = true;
        await setPairingCode(row.id, code);
      });

      // After the starter has created the socket, wire error + connection records
      const sock = getWASocket(sessionId);
      if (sock) {
        sock.__pairingRequestId = row.id;
        sock.__pairingError = (errMsg) => markPairingFailed(row.id, errMsg).catch(() => {});
        sock.ev.on('connection.update', async ({ connection }) => {
          try {
            if (connection === 'open') {
              await markPairingConnected(row.id);
              await recordSession(sessionId, row.phone, 'connected');
            } else if (connection === 'close') {
              await recordSession(sessionId, row.phone, 'disconnected');
              await api(`/api/v1/pairings/${row.id}`, {
                status: 'failed',
                error: 'The pairing session closed before the number was linked. Generate a new code and enter it while the session is open.',
              });
            }
          } catch (_) { /* ignore */ }
        });
      }
    } catch (e) {
      // 401 means the token was revoked - keep polling so it recovers if the bot is re-issued.
      console.error('[TOKEN-BRIDGE] poll error:', e && (e.message || e));
    }
  }, 1000);
}

module.exports = {
  startTokenBridgeLoop,
  getWASocket,
  recordSession,
  getRemoteConfig: () => refreshConfig(null),
  // Whether the bridge is configured, as a value rather than as an exception.
  hasBridge: Boolean(BRIDGE_URL && BRIDGE_TOKEN),
  BRIDGE_URL,
};
