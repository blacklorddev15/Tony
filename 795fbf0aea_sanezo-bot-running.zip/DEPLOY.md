# Back multipair fixed build

This is the corrected non-obfuscated multipair source from the Back repository.

```bash
npm install
node index.js
```

Configure the required environment values before starting. Pairing/session files and database data
are intentionally excluded from this archive.
