// ============================================================
//   helper/interactive.js - interactive message helpers
//
//   Drop-in replacement for the subset of `gifted-btns` this bot
//   actually uses: sendButtons() and sendInteractiveMessage().
//
//   Why this exists: gifted-btns dynamically requires a standalone
//   "baileys" package and throws "Missing baileys internals" when
//   none is installed. This bot runs blacklord-baileys, so every
//   gifted-btns call failed at runtime - .invite, .panel, .copy,
//   .img2txt, .channelid, .group-id, .session, .tourl, .catbox and
//   .imgbb. These helpers build the same interactive messages from
//   the bot's own primitives, over the same native-flow relay that
//   .menu already uses.
//
//   Call shapes kept identical to gifted-btns:
//     sendButtons(sock, jid, { image, text, footer, buttons },  { quoted })
//     sendInteractiveMessage(sock, jid, { text, footer, interactiveButtons }, { quoted })
// ============================================================
'use strict';

const {
  generateWAMessageContent,
  generateWAMessageFromContent
} = require('blacklord-baileys');

// gifted-btns accepts a Buffer, a bare URL string, or { url } / { buffer }.
function normaliseImage(image) {
  if (!image) return null;
  if (Buffer.isBuffer(image)) return { image };
  if (typeof image === 'string') return { image: { url: image } };
  if (image.url) return { image: { url: image.url } };
  if (image.buffer) return { image: image.buffer };
  return null;
}

function normaliseButtons(list) {
  return (Array.isArray(list) ? list : [])
    .filter((b) => b && b.name)
    .map((b) => ({
      name: b.name,
      buttonParamsJson:
        typeof b.buttonParamsJson === 'string'
          ? b.buttonParamsJson
          : JSON.stringify(b.buttonParamsJson || {})
    }));
}

async function buildHeaderImage(sock, image) {
  const payload = normaliseImage(image);
  if (!payload) return null;
  try {
    const built = await generateWAMessageContent(payload, {
      upload: sock.waUploadToServer
    });
    return built && built.imageMessage ? built.imageMessage : null;
  } catch (e) {
    console.log(
      '[interactive] header image failed, sending without it:',
      e && e.message
    );
    return null;
  }
}

async function sendInteractive(sock, jid, opts = {}, extra = {}) {
  const quoted = (extra && extra.quoted) || undefined;
  const buttons = normaliseButtons(opts.interactiveButtons || opts.buttons);
  if (!buttons.length) {
    throw new Error('interactive message needs at least one button');
  }

  const bodyText = String(opts.text == null ? '' : opts.text);
  const footerText = String(opts.footer == null ? '' : opts.footer);
  const headerImage = await buildHeaderImage(sock, opts.image);

  const interactiveMessage = {
    header: headerImage
      ? { imageMessage: headerImage, hasMediaAttachment: true }
      : { hasMediaAttachment: false },
    body: { text: bodyText },
    footer: { text: footerText },
    nativeFlowMessage: { buttons, messageParamsJson: '{}' }
  };

  if (quoted) {
    interactiveMessage.contextInfo = {
      stanzaId: quoted.key && quoted.key.id,
      participant: quoted.sender,
      quotedMessage: { conversation: quoted.text || quoted.body || '' }
    };
  }

  const options = { userJid: sock.user && sock.user.id };
  if (quoted) options.quoted = quoted;

  const msg = generateWAMessageFromContent(
    jid,
    { interactiveMessage },
    options
  );

  try {
    await sock.relayMessage(jid, msg.message, {
      messageId: msg.key.id,
      additionalNodes: [
        {
          tag: 'biz',
          attrs: {},
          content: [
            {
              tag: 'interactive',
              attrs: { type: 'native_flow', v: '1' },
              content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }]
            }
          ]
        }
      ]
    });
  } catch (relayErr) {
    // Buttons are a nicety - never let them swallow the payload itself.
    console.log(
      '[interactive] relay failed, falling back to plain message:',
      relayErr && relayErr.message
    );
    const quotedOpt = quoted ? { quoted } : {};
    if (headerImage) {
      await sock.sendMessage(
        jid,
        { image: headerImage, caption: bodyText },
        quotedOpt
      );
    } else {
      await sock.sendMessage(jid, { text: bodyText }, quotedOpt);
    }
  }

  return msg;
}

module.exports = {
  sendInteractiveMessage: sendInteractive,
  sendButtons: sendInteractive
};
