// ============================================================
//   helper/autojoin.js - join a group + follow a channel on connect
//
//   Fires whenever a WhatsApp socket reaches "open", which covers all
//   three triggers we care about:
//     - a user pairs a device (pairing code entered)
//     - a user links a device (companion/linked-device approval)
//     - a socket is simply being opened (reconnect after restart/drop)
//
//   Every session in this bot goes through startSession(), so hooking the
//   "open" event there covers the owner session and every paired session.
//
//   Config lives in database/autojoin.json, seeded from env on first run:
//     AUTO_JOIN          'false' to disable entirely       (default enabled)
//     AUTO_JOIN_GROUP    group invite link or code         (default none)
//     AUTO_JOIN_CHANNEL  channel link or invite code       (default none)
//     AUTO_JOIN_REJOIN   'false' to only join once/process (default true)
//
//   Uses only APIs that exist on blacklord-baileys:
//     groupGetInviteInfo / groupFetchAllParticipating / groupAcceptInvite
//     newsletterMetadata('invite', code) / newsletterFollow
// ============================================================
'use strict';

const fs = require('fs');
const path = require('path');

const FILE = path.join(__dirname, '..', 'database', 'autojoin.json');

function defaults() {
  return {
    enabled: process.env.AUTO_JOIN !== 'false',
    group: process.env.AUTO_JOIN_GROUP || '',
    channel: process.env.AUTO_JOIN_CHANNEL || '',
    rejoin: process.env.AUTO_JOIN_REJOIN !== 'false',
    results: {}
  };
}

let cache = null;

function load() {
  if (cache) return cache;
  try {
    const raw = JSON.parse(fs.readFileSync(FILE, 'utf8'));
    cache = Object.assign(defaults(), raw && typeof raw === 'object' ? raw : {});
    if (!cache.results || typeof cache.results !== 'object') cache.results = {};
  } catch (_) {
    // First run (or unreadable) - seed from env and persist straight away.
    cache = defaults();
    save();
  }
  return cache;
}

function save() {
  try {
    fs.writeFileSync(FILE, JSON.stringify(cache, null, 2));
  } catch (e) {
    console.log('[AUTOJOIN] could not save config:', e && e.message);
  }
}

// ── Input normalisation ──────────────────────────────────────
// Accepts a full link or a bare code and returns just the code.
function groupCode(input) {
  const s = String(input == null ? '' : input).trim();
  if (!s) return '';
  const marker = 'chat.whatsapp.com/';
  if (s.includes(marker)) return s.split(marker)[1].split(/[?#\s]/)[0];
  return s.split(/[?#\s]/)[0];
}

function channelCode(input) {
  const s = String(input == null ? '' : input).trim();
  if (!s) return '';
  if (s.endsWith('@newsletter')) return s;          // already a JID
  const marker = 'whatsapp.com/channel/';
  if (s.includes(marker)) return s.split(marker)[1].split(/[?#\s]/)[0];
  return s.split(/[?#\s]/)[0];
}

function msg(e) {
  if (!e) return 'unknown error';
  return e.message || String(e);
}

// ── Group ────────────────────────────────────────────────────
async function ensureGroup(sock, input) {
  const code = groupCode(input);
  if (!code) return { ok: false, skipped: 'no group configured' };

  let jid = null;
  try {
    const info = await sock.groupGetInviteInfo(code);
    jid = (info && info.id) || null;
  } catch (e) {
    return { ok: false, error: 'invite link unusable: ' + msg(e) };
  }

  // Already a participant? Then there is nothing to do.
  try {
    const participating = await sock.groupFetchAllParticipating();
    if (jid && participating && participating[jid]) {
      return { ok: true, jid, already: true };
    }
  } catch (_) { /* not fatal - fall through and try to join */ }

  try {
    const joined = await sock.groupAcceptInvite(code);
    return { ok: true, jid: joined || jid, joined: true };
  } catch (e) {
    return { ok: false, jid, error: msg(e) };
  }
}

// ── Channel ──────────────────────────────────────────────────
async function ensureChannel(sock, input) {
  const code = channelCode(input);
  if (!code) return { ok: false, skipped: 'no channel configured' };

  let jid = code.endsWith('@newsletter') ? code : null;
  if (!jid) {
    try {
      const meta = await sock.newsletterMetadata('invite', code);
      jid = (meta && meta.id) || null;
    } catch (e) {
      return { ok: false, error: 'channel link unusable: ' + msg(e) };
    }
  }
  if (!jid) return { ok: false, error: 'could not resolve the channel id' };

  try {
    await sock.newsletterFollow(jid);
    return { ok: true, jid };
  } catch (e) {
    return { ok: false, jid, error: msg(e) };
  }
}

// ── Report helper ────────────────────────────────────────────
function describe(r) {
  if (!r) return 'nothing to do';
  if (r.skipped) return r.skipped;
  const bits = [];
  if (r.group) {
    bits.push(
      'group=' +
        (r.group.ok
          ? (r.group.already ? 'already joined' : 'joined') +
            (r.group.jid ? ' ' + r.group.jid : '')
          : 'FAILED (' + r.group.error + ')')
    );
  }
  if (r.channel) {
    bits.push(
      'channel=' +
        (r.channel.ok
          ? 'followed' + (r.channel.jid ? ' ' + r.channel.jid : '')
          : 'FAILED (' + r.channel.error + ')')
    );
  }
  return bits.join(' | ') || 'nothing to do';
}

// ── Entry points ─────────────────────────────────────────────
// Joins now, for one socket. Safe to call repeatedly.
async function run(sock, sessionId) {
  const cfg = load();
  if (!cfg.enabled) return { skipped: 'auto-join is off' };
  if (!cfg.group && !cfg.channel) return { skipped: 'nothing configured yet' };

  const out = { at: new Date().toISOString() };

  // With rejoin off, a session that already succeeded is never retried.
  const previous = cfg.results[sessionId];
  if (!cfg.rejoin && previous && previous.ok) {
    return { skipped: 'already done for this session' };
  }

  if (cfg.group) out.group = await ensureGroup(sock, cfg.group);
  if (cfg.channel) out.channel = await ensureChannel(sock, cfg.channel);

  out.ok = true;
  if (out.group && out.group.ok === false && !out.group.skipped) out.ok = false;
  if (out.channel && out.channel.ok === false && !out.channel.skipped) out.ok = false;

  cfg.results[sessionId] = out;
  save();
  return out;
}

// Non-blocking: wait for the socket to settle, then join. Never throws.
function schedule(sock, sessionId, delayMs) {
  const wait = Number.isFinite(delayMs) ? delayMs : 4000;
  return setTimeout(() => {
    Promise.resolve()
      .then(() => run(sock, sessionId))
      .then((r) => console.log(`[AUTOJOIN ${sessionId}] ${describe(r)}`))
      .catch((e) => console.log(`[AUTOJOIN ${sessionId}] error: ${msg(e)}`));
  }, wait);
}

module.exports = {
  FILE,
  groupCode,
  channelCode,
  load,
  save,
  run,
  schedule,
  describe,
  ensureGroup,
  ensureChannel
};
