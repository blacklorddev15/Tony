# Where secrets go (read this before re-uploading)

Uploading a folder over `/home/container` **overwrites `.env`**. If you keep a token only in
`.env`, an upload can silently wipe it and the bot will log it as "not set".

Durable place: **Panel → your server → Startup → `CUSTOM_ENVIRONMENT_VARIABLES`**
(semicolon-separated). The startup command exports each entry, so it survives file uploads:

```
BRIDGE_URL=https://token-bridge-eosin.vercel.app;BRIDGE_TOKEN=tb_...
```

`.env` still works, and is what this bot used, but treat it as disposable.
