# Multi-bot fixes

This build includes:

1. **Waiting-for-this-message fix**
   - A private store for every WhatsApp session.
   - `getMessage` backed by that session store.
   - Per-session `msgRetryCounterCache`.
   - Cached Signal key store.
   - `fireInitQueries: false` and history sync disabled.
   - Group metadata cache with invalidation on group changes.

2. **Startup crash fix**
   - A defensive module-level store fallback prevents legacy top-level handlers from throwing
     `ReferenceError: store is not defined`.
   - Live sessions continue to use their own private stores; the fallback is not shared by normal
     session message handling.

Do not copy old session files or `.env` into a different deployment. Install dependencies, configure
an environment file, and pair/restart the affected numbers after deployment.
