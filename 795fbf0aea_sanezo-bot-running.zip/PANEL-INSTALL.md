# Running this on a Pterodactyl panel

## Requirements
- Node.js 18+ (egg here: `yolks:nodejs_24`)
- Outbound access to web.whatsapp.com, g.whatsapp.net and token-bridge-eosin.vercel.app

## Install
1. Upload everything to `/home/container`, keeping `lib/`, `helper/`, `database/`.
2. `npm install`
3. Startup command: `npm start`   ( → `node index.js` )
4. Start.

## .env
```
# Neon bridge disabled - pairing goes through the token bridge only.
# NEON_DATABASE_URL=postgresql://...
BRIDGE_URL=https://token-bridge-eosin.vercel.app
BRIDGE_TOKEN=tb_...
```
Optional: TELEGRAM_TOKEN, SESSION_ID, PREFIX, BOT_NAME.

## Files
| File | Role |
|---|---|
| index.js | entry point, session manager, channel wiring |
| Sanezo.js | all WhatsApp command handlers (337 commands) |
| config.js | globals + defaults |
| helper-bridge-token.js | token bridge channel (HTTPS + BRIDGE_TOKEN) |
| helper-varnox-neon.js | Neon bridge channel (unused while NEON_DATABASE_URL is commented out) |
| helper-bridge-token.js | Token bridge channel (website pairing) |
| lib/, helper/, database/ | helpers and runtime state |

Not included: `node_modules/`, `sessions/` (per-server WhatsApp auth - do not share),
build artefacts.
