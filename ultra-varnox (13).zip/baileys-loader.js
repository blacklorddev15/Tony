'use strict'

let loaded

async function loadBaileys() {
  if (loaded) return loaded
  const mod = await import('@whiskeysockets/baileys')
  loaded = { ...mod, default: mod.default || mod.makeWASocket }

  // Compatibility helpers expected by this CommonJS bot.
  if (!loaded.fetchLatestBaileysVersion) {
    loaded.fetchLatestBaileysVersion = async () => ({ version: [2, 3000, 0], isLatest: true })
  }
  if (!loaded.makeCacheableSignalKeyStore) {
    loaded.makeCacheableSignalKeyStore = (keys) => keys
  }
  if (!loaded.areJidsAnimeMdUser) {
    loaded.areJidsAnimeMdUser = loaded.areJidsSameUser || ((a, b) => String(a || '') === String(b || ''))
  }

  global.Baileys = loaded
  return loaded
}

module.exports = { loadBaileys }
