import { createEphotoCommand } from './ephotoUtils.js';
export default createEphotoCommand('crack3d');
