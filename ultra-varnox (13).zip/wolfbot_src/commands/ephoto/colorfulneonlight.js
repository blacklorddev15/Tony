import { createEphotoCommand } from './ephotoUtils.js';
export default createEphotoCommand('colorfulneonlight');
