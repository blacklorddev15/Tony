import { createPhotofuniaCommand } from './photofuniaUtils.js';
export default createPhotofuniaCommand('love-lock');
