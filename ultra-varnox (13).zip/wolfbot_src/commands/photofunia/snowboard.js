import { createPhotofuniaCommand } from './photofuniaUtils.js';
export default createPhotofuniaCommand('snowboard');
