// ============================================================
//   helper/scope.js  –  per-WhatsApp-account data scoping
// ------------------------------------------------------------
//   Every WhatsApp number that pairs with this panel is a separate
//   tenant. Settings were already keyed by number (helper/function.js);
//   this module does the same for the JSON data stores so one account
//   can never read or overwrite another account's data.
//
//   Layout:  database/accounts/<waNum>/<file>.json
//   Fallback: 'default' bucket when a socket has no number yet.
// ============================================================
'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..', 'database', 'accounts');
let active = 'default';

function safeNum(n) {
  const s = String(n == null ? '' : n).replace(/[^0-9]/g, '');
  return s || 'default';
}

function setActiveAccount(waNum) {
  active = safeNum(waNum);
  ensureAccount(active);
  return active;
}

function activeAccount() {
  return active;
}

function ensureAccount(waNum) {
  const dir = path.join(ROOT, safeNum(waNum));
  try { fs.mkdirSync(dir, { recursive: true }); } catch {}
  return dir;
}

function accountDir(waNum) {
  return ensureAccount(waNum == null ? active : waNum);
}

// Path to a scoped data file, e.g. dataFile('economy.json')
function dataFile(name, waNum) {
  const base = String(name || 'store.json').replace(/^[\\/]+/, '').split('..').join('');
  const dir = accountDir(waNum);
  return path.join(dir, path.basename(base));
}

function readData(name, fallback, waNum) {
  try {
    const file = dataFile(name, waNum);
    if (!fs.existsSync(file)) return fallback;
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return fallback;
  }
}

function writeData(name, value, waNum) {
  try {
    const file = dataFile(name, waNum);
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify(value, null, 2));
    return true;
  } catch {
    return false;
  }
}

module.exports = {
  setActiveAccount,
  activeAccount,
  accountDir,
  ensureAccount,
  dataFile,
  readData,
  writeData,
  ROOT,
};
