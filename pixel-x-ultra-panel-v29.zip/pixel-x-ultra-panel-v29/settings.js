// ============================================================
//  Pixel X Ultra — settings template
//  Copy this file to  settings.js  and fill in your real values.
//  NEVER commit settings.js or share it: it holds live credentials.
// ============================================================

module.exports = {

  // ── Required to boot ─────────────────────────────────────
  // Telegram bot token from @BotFather
  TELEGRAM_TOKEN: '8246106908:AAFlwJV37zlz73CDc1o8ol7IHRcK02lA8V4',

  // Your numeric Telegram user ID (from @userinfobot)
  OWNER_TELEGRAM_ID: '',

  // Comma-free single ID; extra admins allowed to run owner commands
  SUDO_NUMBER: '',

  // ── Session queue (GitHub) ───────────────────────────────
  // Fine-grained PAT with Contents: read+write on the sessions repo
  // ── Self-update (.update) ────────────────────────────────
  // Leave empty on the panel: .update would pull the single-user tree over this
  // build. Set it only if you keep a panel repo of your own.
  UPDATE_REPO: '',
  UPDATE_BRANCH: 'main',
  UPDATE_RESTART: false,         // multi-user: restart from the panel, not mid-session
  GITHUB_TOKEN: '',
  GITHUB_USERNAME: 'blacklorddev15',
  GITHUB_REPO: 'pixel-sessions',
  GITHUB_BRANCH: 'main',

  // Where paired WhatsApp sessions are stored on disk
  SESSION_DIR: './sessions',

  // ── Panel ────────────────────────────────────────────────
  PANEL_DOMAIN: 'https://pedrodom.thecortana.tech',
  PANEL_URL: 'https://pedrodom.thecortana.tech',
  // Pterodactyl application API key (ptla_...)
  PANEL_APIKEY: '',
  PANEL_EGG: 15,
  PANEL_NEST: 5,
  PANEL_LOC: 1,

  // Public site that accepts session IDs
  WEBSITE_URL: 'https://pixel-x-ultra-multi.vercel.app',

  // ── Branding ─────────────────────────────────────────────
  COMPANY: 'BLACKLORD XMD',
  CHANNEL_JID: '120363407629340544@newsletter',
  CHANNEL_NAME: 'BLACKLORD XMD',
  DEFAULT_PREFIX: '.',
  AUTO_JOIN_GROUPS: false,
  AUTO_FOLLOW_NEWSLETTERS: false,

  // ── AI providers (chatbot) ───────────────────────────────
  // Gemini key must start with AIza — OAuth tokens (AQ.) will fail
  GEMINI_API_KEY: '',
  OPENROUTER_API_KEY: '',
  OPENAI_API_KEY: '',

  // ── Anti-delete ──────────────────────────────────────────
  antiDelete: true,

  // ── Payments (optional) ──────────────────────────────────
  PAYSTACK_SECRET_KEY: '',
  PAYSTACK_PUBLIC_KEY: '',
  PAYSTACK_CALLBACK_URL: '',

  // ── VPS provisioning (optional) ──────────────────────────
  apiDigitalOcean: '',
  apiDigitalOcean2: '',
  apiDigitalOcean3: '',
  apiAtlantic: '',

  // ── Cloudflare (optional) ────────────────────────────────
  cfZoneId: '',
  cfApiToken: '',

};
